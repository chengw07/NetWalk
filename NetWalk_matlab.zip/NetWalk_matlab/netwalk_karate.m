%% Example of embedding static graph karate
%  load graph karate and using netwalk to embed each node into d(e.g.,2)
%  dimentional space code and visualize each points with different colors
%  for different labels
clear; clc;
addpath framework/ optimize/
rng(300)

walk_len = 3;
sample_per_node = 20;

[~, n, mat] = load_karate();


%% Generate walks
[walks_onehot, reservoir, degree, walks]= netwalk_generation(mat, n, walk_len, sample_per_node);


d = 2;                  % number of hidden layer
rho = 0.2;              % rho, spasity parameter
gama = 10;              % weight of autoencoder (reconstruction error)
beta = 0.3;             % weight of sparsity regularization
lamda = 5e-5;           % weight decay parameter

%% Initialize parameters for optimization
theta = initialize(d, n);

options.Method = 'lbfgs';
options.maxIter = 500;	  % Maximum number of iterations of L-BFGS to run
options.display = 'off';


%% Invoke optimizing package for optimizing
[opttheta, cost] = minFunc( @(p) clique_embedding(p, n, d, walk_len, rho, gama, beta, lamda, walks_onehot), theta, options);

%% Unpack parameters
W1 = reshape(opttheta(1:d*n), d, n);           % W1 in R^d*n
W2 = reshape(opttheta(d*n+1:2*d*n), n, d);     % W2 in R^n*d
b1 = opttheta(2*d*n+1:2*d*n+d);                % b1 in R^d
b2 = opttheta(2*d*n+d+1:end);                  % b2 in R^d

hiddeninputs = W1 * speye(n) + b1 * ones(1, n);      % d * n
embedding = sigmoid( hiddeninputs );                 % d * n
out = sigmoid(W2 * embedding + b2 * ones(1, n));

%% Visualizing embeding results in 2-dimentional space
membership = importdata('./data/output/membership.txt');
for i = 1:length(membership)
    switch membership(i)
        case 1
            color = '*r';
        case 2
            color = '*b';
        case 3
            color = '*g';
        case 4
            color = '*k';
    end
    plot(embedding(1, i), embedding(2, i), color)
    hold on
end
