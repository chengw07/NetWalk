function [walks_onehot, reservoir, degree, walks] = netwalk_generation(mat, n, walk_len, sample_per_node)

%% generate walk with length ``walk_len'', ``sample_rate'' parameter
% check walk generate by the node degree, and node generate by assign
% equation number for each node. If these two approaches follow the
% power-low distribution.
% Input:  mat: square matrix format of input graph/network, size: n * n
%         n:   number of nodes in the graph, should be equal to length(mat)
%         walk_len: parameter to control the length of walk, here we use 3
%         sample_per_node: parameter to control number of walks for each
%                          node
% Output: walks_onehot: onehot vectors for all sampled walk's,
%                       it should be n * (walk_len*sample_per_node*number
%                       of walks), each column is one node, every 3
%                       continus columns is one walk path sampled, each row
%                       is one dimension of onehot feature, this should be
%                       the number of total nodes.
%         reservoir:  reservoir for online sampling new walks for new coming
%                     edges. 
%                    Example: if there is 5 nodes in total, for each node we
%                           sample 2(sample_per_node) then the reservoir is like, 
%                           2  4    -----sampling neigbours of node 1
%                           4  1    -----sampling neigbours of node 2
%                           3  3    -----sampling neigbours of node 3 (this
%                                        case node 3 has no neigbour)
%                           5  2    -----sampling neigbours of node 4
%                           1  3    -----sampling neigbours of node 5
%         degree: 1 * n vector recording degrees of each node
%         walks:  all walks with length(walk_len), each row is one walk,
%                 nodes without edges associated will not included in it
%                     1 240 284     -----walk path 1->240->284
%                     1 2 1
%                     1 240 741
%                     2 1 2
%                     2 1 23 
%                       .
%                       .
%                       .
%

fprintf('[%s] netwalk generation for staic graph...\n', datestr(now, 'mm/dd/yy HH:MM:SS'))
fprintf('[%s] walk length: %d, samples per node: %d.\n', ...
    datestr(now, 'mm/dd/yy HH:MM:SS'), walk_len, sample_per_node)

walks = zeros(sample_per_node * n, walk_len);
reservoir = zeros(n, sample_per_node);

% random walk method
for i = 1:length(mat)
    if sum(mat(i, :)) == 0
        % fprintf('no edges for node %d\n', i)
        continue
    end
    
    % Y = randsample(N,K,true,W) or randsample(POPULATION,K,true,W) returns a
    % weighted sample, using positive weights W, taken with replacement.  W is
    % often a vector of probabilities. This function does not support weighted
    % sampling without replacement.
    walk_block = zeros(sample_per_node, walk_len);
    walk_block(:, 1) = repmat(i, sample_per_node, 1);
    for k = 2:walk_len
        for j = 1:sample_per_node
            start_node = walk_block(j, k-1);
            idx = find(mat(start_node, :));
            if length(idx) == 1
                walk_block(j, k) = idx;
            else
                walk_block(j, k) = randsample(idx, 1); % for unweighted graph only
            end
        end
    end
    walks(((i-1)*sample_per_node + 1): i*sample_per_node,:) = walk_block;
    reservoir(i,:) = walk_block(:, 2);
end
walks = walks(walks(:,1) > 0, :);
flat_walk = walks';
walks_onehot = sparse(flat_walk(:), 1:length(walks) * walk_len, ones(length(walks) * walk_len,1), n, length(walks) * walk_len);

degree = full(sum(mat));

end

