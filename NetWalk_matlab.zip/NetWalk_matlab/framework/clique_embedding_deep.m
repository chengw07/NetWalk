function [loss, grad] = clique_embedding_deep(theta, n, d, walk_len, rho, gama, beta, lamda, data)
%% CLIQUE_EMBEDDING_DEEP:
%   using walk data in options.walk_len to conduct node embedding;
%   all hyper-parameters are in options
%   Output:  embedding--- R^(n * d) the embeddings of each node, each row
%                           is one node, each column is one hidden
%                           dimension
%            opttheta---  the optimal parameters learned in the model, one
%                         vector that concatinating all parameters used, 
%                         
% loss function: clique embedding + \gamma autoencoder + \beta sparsity + \lambda weight decay
% This is a deep version of objective function with gradient
% There are 6 layers in the nenral network, 3 layers for encoding, 3 layers
% for decoding;
% theta: is the parameters for optimization;
% walk_len: the length of walk
% n: visible size, number of vertices
% d: hidden size, feature space size
% rho: sparsity parameter
% gama: weight of autoencoder (reconstruction error)
% beta: weight of sparsity regularization
% lamda: weight of weight decay term
    
W1 = reshape(theta(1:d*n), d, n);           % W1 in R^d*n

W2 = reshape(theta(d*n+1:d*n+d*d), d, d);     
W3 = reshape(theta(d*n+d*d+1:d*n+2*d*d), d, d);    
W4 = reshape(theta(d*n+2*d*d+1:d*n+3*d*d), d, d);     
W5 = reshape(theta(d*n+3*d*d+1:d*n+4*d*d), d, d);     

W6 = reshape(theta(d*n+4*d*d+1:2*d*n+4*d*d), n, d);     % W6 in R^n*d

b1 = theta(2*d*n+4*d*d+1:2*d*n+4*d*d+d);                % b1 in R^d
b2 = theta(2*d*n+4*d*d+d+1:2*d*n+4*d*d+2*d);
b3 = theta(2*d*n+4*d*d+2*d+1:2*d*n+4*d*d+3*d);
b4 = theta(2*d*n+4*d*d+3*d+1:2*d*n+4*d*d+4*d);
b5 = theta(2*d*n+4*d*d+4*d+1:2*d*n+4*d*d+5*d);
b6 = theta(2*d*n+4*d*d+5*d+1:end);                  % b2 in R^d

% input -> h2 -> h3 -> h4 (code) -> h5 -> h6 -> output (h7)
l_omega = size(data, 2);                    % dim is l * |\omega|, |\omega| = k * n, each walk has l vertices
z2 = W1 * data + repmat(b1, [1, l_omega]);  % dim is d * (l * |\omega|)
a2 = sigmoid(z2);                           % hidden layer output

z3 = W2 * a2 + repmat(b2, [1, l_omega]);
a3 = sigmoid(z3);

z4 = W3 * a3 + repmat(b3, [1, l_omega]);
a4 = sigmoid(z4);

z5 = W4 * a4 + repmat(b4, [1, l_omega]);
a5 = sigmoid(z5);

z6 = W5 * a5 + repmat(b5, [1, l_omega]);
a6 = sigmoid(z6);

z7 = W6 * a6 + repmat(b6, [1, l_omega]);
a7 = sigmoid(z7);                           % final output

rhohats = mean(a2, 2);
kl_sum = sum(rho * log(rho ./ rhohats) + (1-rho) * log((1-rho) ./ (1-rhohats)));

squares = (a7 - data).^2;
autoencoder_J = (gama/2) * (1/l_omega) * sum(squares(:));
weight_decay_J = (lamda/2) * (sum(W1(:).^2) + sum(W2(:).^2) + sum(W3(:).^2) + sum(W4(:).^2) + sum(W5(:).^2) + sum(W6(:).^2));
sparsity_J = beta * kl_sum;

phi = 1 - speye(walk_len);
D = sum(phi, 2);
L = spdiags(D,0,speye(size(phi,1)))-phi;

clique_J = 0;
W1_clique = 0; 
b1_clique = 0;
for i = 1:l_omega/walk_len
    f_i = a2(:, ((i-1)*walk_len + 1):i*walk_len);
    data_i = data(:, ((i-1)*walk_len + 1):i*walk_len);
    clique_J = clique_J + trace(f_i * L * f_i');
    W1_clique = W1_clique + f_i*(L+L').*f_i.*(1-f_i)*data_i';
    b1_clique = b1_clique + f_i*(L+L').*f_i.*(1-f_i)*ones(walk_len, 1);
end
       
loss = (walk_len/l_omega) * clique_J + autoencoder_J + weight_decay_J + sparsity_J;

delta7 = -gama * (data - a7) .* a7 .* (1-a7);
delta6 = (W6' * delta7) .* a6 .* (1-a6);
delta5 = (W5' * delta6) .* a5 .* (1-a5);
beta_term = beta * (- rho ./ rhohats + (1-rho) ./ (1-rhohats));
delta4 = ((W4' * delta5) ) .* a4 .* (1-a4);
delta3 = ((W3' * delta4) ) .* a3 .* (1-a3);
delta2 = ((W2' * delta3) + repmat(beta_term, [1, l_omega]) ) .* a2 .* (1-a2);

W6grad = (1/l_omega) * delta7 * a6' + lamda * W6;
b6grad = (1/l_omega) * sum(delta7, 2);
W5grad = (1/l_omega) * delta6 * a5' + lamda * W5;
b5grad = (1/l_omega) * sum(delta6, 2);
W4grad = (1/l_omega) * delta5 * a4' + lamda * W4;
b4grad = (1/l_omega) * sum(delta5, 2);

W3grad = (1/l_omega) * delta4 * a3' + lamda * W3;
b3grad = (1/l_omega) * sum(delta4, 2) ;
W2grad = (1/l_omega) * delta3 * a2' + lamda * W2;
b2grad = (1/l_omega) * sum(delta3, 2);
W1grad = (1/l_omega) * delta2 * data' + lamda * W1 + (walk_len/l_omega) * W1_clique;
b1grad = (1/l_omega) * sum(delta2, 2) + (walk_len/l_omega) * b1_clique;

grad = [W1grad(:); W2grad(:); W3grad(:); W4grad(:); W5grad(:); W6grad(:); b1grad(:); b2grad(:); b3grad(:); b4grad(:); b5grad(:); b6grad(:)];

end

function sigm = sigmoid(x)
    sigm = 1 ./ (1 + exp(-x));
end
