
function [data, n, m] = load_uci_message(sample_rate)
%% function load_uci_message
%  [data, n, m] = load_uci_message(sample_rate)
%  load data set uci_message and preprocess it
%  parameter: sample_rate to subsample edges
%  return data: network(each row is one edge); n: number of total nodes; m:
%  number of edges
%  Example:
%      input orginal file format as following: (nodeID, nodeID, edge
%      weight, timestamp)
%        1 2 1 1082008561
%        3 4 1 1082123439
%        5 2 1 1082381991
%        6 7 1 1082407219
%        8 7 1 1082407356
%        9 10 1 1082408003x cz
%        9 11 1 1082408053
%        12 13 1 1082408788
%        9 14 1 1082409354
%      output: data, n, m
%          data is with format (nodeID, nodeID), each row is one edge
%          n: number of total nodes; m: number of edges
%   Copyright 2018 NEC Labs America, Inc.
%   $Revision: 1.0 $  $Date: 2018/10/26 17:46:36 $
fid = fopen('./data/ucsocial/out.opsahl-ucsocial');
if fid == -1
   error('no file exists ...')
end

digg = textscan(fid, '%f %f %f %f','Delimiter','\n','CommentStyle','%');
digg = cat(2, digg{:});
fclose(fid);

% the data might not in order
digg = sortrows(digg, 4);

% change to undirected graph
idx = find(digg(:, 1) > digg(:, 2));
digg(idx, 1:2) = digg(idx, [2,1]);
% remove self loop
digg = digg(digg(:,1) < digg(:,2), :);

% only keep unique edges
digg = unique(digg(:,1:2), 'rows', 'stable');



if nargin == 1
    step = floor(1/sample_rate);
    digg = digg(1:step:end,:);
end

% re-assign id
unique_id = unique(digg);
n = length(unique_id);
[~,digg] = ismember(digg, unique_id);

data = digg;
m = length(digg);

% mat = sparse(data(:,1), data(:,2), ones(length(data), 1), n, n);
% degree = full(sum(mat + mat'));
% n
% m
% max_degree = max(degree)
% avg_degree = mean(degree)
end
