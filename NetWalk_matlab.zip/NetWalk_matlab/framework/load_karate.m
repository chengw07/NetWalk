function [ edgelist, n, mat] = load_karate()
%% LOAD_KARATE:
% dimension: m * 4; for each record [id1, id2, weight, timestamp]

path = './data/karate.adjlist';
fid = fopen(path);
row = fgets(fid);
edgelist = [];
while ischar(row)
	numbers = sscanf(row, '%f ');
    src = repmat(numbers(1), length(numbers), 1);
    edges = [src numbers];
    edgelist = [edgelist; edges(2:end,:)];
    row = fgets(fid);
end
fclose(fid);

n = length(unique(edgelist(:)));
mat = sparse(edgelist(:,1), edgelist(:,2), ones(length(edgelist), 1), n, n);
end


