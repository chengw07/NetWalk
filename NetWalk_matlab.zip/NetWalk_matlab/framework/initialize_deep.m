function theta = initialize_deep(hiddenSize, visibleSize)

%% Initialize parameters randomly based on layer sizes for 6 layer version

% we'll choose weights uniformly from the interval [-r, r]
r  = sqrt(6) / sqrt(hiddenSize+visibleSize+1);   

W1 = rand(hiddenSize, visibleSize) * 2 * r - r;
W2 = rand(hiddenSize, hiddenSize) * 2 * r - r;
W3 = rand(hiddenSize, hiddenSize) * 2 * r - r;
W4 = rand(hiddenSize, hiddenSize) * 2 * r - r;
W5 = rand(hiddenSize, hiddenSize) * 2 * r - r;
W6 = rand(visibleSize, hiddenSize) * 2 * r - r;

b1 = zeros(hiddenSize, 1);
b2 = zeros(hiddenSize, 1);
b3 = zeros(hiddenSize, 1);
b4 = zeros(hiddenSize, 1);
b5 = zeros(hiddenSize, 1);
b6 = zeros(visibleSize, 1);

% Convert weights and bias gradients to the vector form.
% This step will "unroll" (flatten and concatenate together) all 
% your parameters into a vector, which can then be used with minFunc. 
theta = [W1(:) ; W2(:) ; W3(:) ; W4(:) ;W5(:) ; W6(:) ;b1(:) ; b2(:) ;b3(:) ; b4(:) ;b5(:) ; b6(:)];

end

